/********************************************************************
 * AUTHOR             : Juan Cruz Tapia
 * HOMEWORK           : Assignment 2
 * CLASS              : CSC 17A
 * SECTION            : Tue, Thu:    11:10am - 12:35pm
 * DUE DATE           : 09/08/14
 ********************************************************************/

#include <iostream>
#include <iomanip>
#include <cstring>

using namespace std;

/********************************************************************
 *
 * Assignment 1
 *
 * ------------------------------------------------------------------
 * Menu selection program to run homework assignments:
 * 	10.1
 * 	10.2
 * 	10.3
 * 	10.4
 * 	10.5
 ********************************************************************/

// Functions for the problems

//Count the number of characters in the string and ignores blanks
int length(char *charArray)
{   
    int length = strlen(charArray);
    int spaceCount = 0;
    
    
    for(int i = 0; i <= length; i++)
    {
        if(charArray[i] == ' ')
        {
            spaceCount++;
        }
    }
    
    return (length - spaceCount);
}
// Reverses the letters in a string and displays it
void reverseString(char *charArray)
{
    //Calling the length function
    int stringLength = length(charArray);
    
    cout << "\nYour string backwards reads: \n";
    
    for(int i = (stringLength + 1); i >= 0; i--)
    {
        cout << charArray[i];
    }
    
    cout << endl;
}
// Counts the number of words in a phrase
int numberWords(string phrase)
{
    //Declare variables
    int count = 1;
    int length = phrase.length();
    
    //Count how many words
    for(int i = 0; i <= length; i++)
    {
        if(phrase[i] == ' ')
        {
            count++;
        }
    }
    
    return count;
}
// Capitalizes the first letter for each sentence
void sentenceCapitalizer(string phrase)
{
    //Declare variables
    int length = phrase.length();
    
    phrase[0] = toupper(phrase[0]);
    //Count how many words
    for(int i = 0; i <= length; i++)
    {
        if(phrase[i] == '.')
        {
            phrase[i + 2] = toupper(phrase[i + 2]);
        }
    }
    
    cout << "\nHere is your capitalized paragraph: " << endl;
    cout << phrase << endl;
}

// Chapter 10 problems
void stringLenght()
{
     //Declare variables
    int size = 50;
    char cString[size];
    int count;
    
    cin.ignore();
    //Input a string
    cout << "\nInput a string and the program will give you the number of "
            "characters in the string" << endl;
    cin.getline(cString, size);
    
    count = length(cString);
    //Display Functions Return Value
    cout << "The number of characters in the string is " << count << "." << endl;
}
void backwardString()
{
    //Declare variables
    int size = 100;
    char charArray[size];
    
    cin.ignore();
    //Input a string
    cout<<"\nInput a string and the program will display the string "
          "backwards" << endl;
    cin.getline(charArray, size);
    
    //Reverse Function
    reverseString(charArray);
}
void wordCounter()
{
    //Declare variables
    string words;
    int wordCount;
    
    cin.ignore();
    //Input a string
    cout<<"\nInput a phrase and the program will give you the number of words in "
           "the phrase"<< endl;
    getline(cin, words);
    wordCount = numberWords(words);
    
    cout << "\nYour phrase has "<< wordCount << " words."<< endl;
}
void averageNumberLetters()
{
    //Declare variables
    string words;
    int wordCount;
    float totalLetters;
    float letterAverage;
    
    cin.ignore();
    //Input a string
    cout << "\nInput a phrase and the program will calculate the average number of "
            "letters per word" << endl;
    getline(cin, words);
    
    wordCount = numberWords(words);
    totalLetters = words.length();
    letterAverage = (totalLetters - (wordCount - 1)) / wordCount;
    
    cout << setprecision(2) << fixed;
    cout << "\nThe average number of letters per word is "<< letterAverage 
         << " letters."<< endl;
}
void sentenceCapitalizer()
{
    string uncapWords;
    
    cin.ignore();
    cout << "\nInput a small paragraph in all lowercases. The program will "
         << "capitalize the first letter of each sentence" << endl;
    getline(cin, uncapWords);
    
    sentenceCapitalizer(uncapWords);
}

int main ()
{
		// Declaring variables
		int problemNumber;
		char cont = 'N';

		// Menu loop to select the problem
		do
		{
			cout << "\nPlease enter the number of the problem you "
                                "would like to run or press '0' to exit\n";
			cout << "\t1 = 10.1\n\t2 = 10.2\n\t3 = 10.3\n"
                                "\t4 = 10.4\n\t5 = 10.5\n"
				"\t0 = EXIT" << endl;
			cin >> problemNumber;

			// Loop in case the user wants to run the same problem
			do
			{
				switch (problemNumber)
				{
				  case 1:
				  	  stringLenght();
				  	  break;
				  case 2:
				  	  backwardString();
					  break;
				  case 3:
				  	  wordCounter();
					  break;
				  case 4:
				  	  averageNumberLetters();
					  break;
				  case 5:
				  	  sentenceCapitalizer();
				  	  break;
				  case 0:
				  	  break;
				  default:
					  cout<<"That's an invalid entry\n";
					  break;
				}
			}while(problemNumber < 1 || problemNumber > 7);
                        
                        cout << "\nDo you want to run the "
                                "program again? ('Y' to "
                                "continue or any other key to "
                                "cancel)";
				cin >> cont;

		}while(toupper(cont) == 'Y');

        return 0;
}
